# AGENTS.md

## 1. Repository Role

この repository は Windows CE の公開資料・情報を収集、整理、解析し、
`Akari-dev` が Development API Surface Kit を構築するための前提 corpus を作る repository です。

`wince-docs-corpus` は `Akari-dev` の実装 repository ではありません。
SDK、BSP、OAK、Windows CE OS の再実装を目的としません。

## 2. Fixed Repository Structure

以下の既存構造を維持します。作業上の都合だけで変更しません。

```text
wince-docs-corpus/
├── .github/
├── AGENTS/
├── archive/
├── data/
├── docs/
├── pagesmap/
├── supplementary/
├── tools/
├── analys/
└── urls/
```

主な作業領域は `tools/`, `urls/`, `docs/`, `analys/` です。

- `urls/` — 収集対象 URL
- `docs/` — 取得した資料
- `tools/` — 収集・変換・検証 scripts
- `analys/` — 解析・database 生成
- `data/` — 機械可読な整理済みデータ
- `archive/` / `supplementary/` / `pagesmap/` — 既存の用途に従って扱う

## 3. Basic Workflow

```text
1. 既存 corpus を確認
↓
2. tools / docs / urls / analys / data を確認
↓
3. SEARCH.md に従って調査
↓
4. URL を urls/ に整理
↓
5. HARVEST.md に従って資料を収集
↓
6. 収集結果を検証
↓
7. ANALYSIS.md に従って database を生成・更新
↓
8. CHECK.md に従って corpus / database を検証
↓
9. 監査方法そのものを再確認
↓
10. Git state を確認
↓
11. commit / push
↓
12. Akari-dev の作業へ戻る
```

## 4. Evidence and Provenance

収集情報について、少なくとも以下を区別します。

- 直接確認できる公開事実
- 資料から導出した情報
- 複数資料の突き合わせによる判断
- 推測
- third-party による解釈
- 実装との比較結果

URL、資料、取得方法、必要な metadata の対応関係を可能な限り維持します。

## 5. Source Policy

情報源の扱いは `SEARCH.md` と `CLEANROOM.md` に従います。

原則として、公開された合法的な情報を対象とします。
ただし Microsoft の Shared Source、Visual Studio、Platform Builder 等については、
ソースコードの収集・コピー・再配布を目的とした調査を行いません。

これらについては、公開された開発資料等から WinCE の仕様、API、型、ABI、
header 名、DLL、version 差分等を確認する範囲に限定します。

## 6. API Database Goal

最終的に、Akari-dev の構築に必要な Windows CE 情報を、可読かつ機械可読な
database として整理します。

特に以下を世代情報とともに追跡します。

- API name
- function / prototype
- type
- constant
- structure / layout information
- header name
- DLL
- export
- import library
- calling / ABI information
- kernel/user mode 等の配置情報
- Windows CE generation / version
- availability
- source / evidence

API を関数単位だけでなく、

```text
CE generation
    ↓
DLL
    ↓
export
    ↓
API
    ↓
header / ABI / availability
```

という逆方向も含めて整理します。

## 7. Completion

資料収集だけでなく、database の欠落、世代区分、provenance、情報の整合性、
scripts の不具合、収集情報と database の不一致を確認してから完了とします。

監査は一度で終了とせず、監査内容・条件・scripts 自体も再確認します。

詳細は `AGENTS/` 以下の文書に従います。
