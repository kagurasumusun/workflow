# AGENTS.md

## 1. Repository Role

このリポジトリはWindows CEの資料・情報を収集するリポジトリです。

このrepositoryで収集・整理した情報は、`Akari-dev` におけるWindows CE Development API Surface Kitの構築に利用します。

---

## 2. Repository Structure

以下のrepository構造を維持します。

```text
Akari-dev/
├── .github/
├── AGENTS/
├── archive/
├── data/
├── docs/
├── pagesmap/
├── supplementary/
├── tools/
├── analys/
└── urls/
```

`docs/` 配下にはサイトの大まかな種類ごとにフォルダ分けをして資料を収集します。

`urls/` 配下にはサイトの種類ごとにURLをまとめます。

`tools/` 配下には使用するスクリプト等を配置します。

---

## 3. Primary Working Areas

基本的には以下を使用します。

```text
tools/
urls/
docs/
analys/
```

各ディレクトリの既存構造および用途を確認してから変更してください。

既存のrepository構造を、作業上の都合だけで変更しないでください。

---

# 4. Basic Workflow

`wince-docs-corpus` では、原則として以下のワークフローを繰り返します。

```text
1. 既存wince-docs-corpus確認
↓
2. tools / docs / urlsを確認
↓
3. Search.mdに従ってWeb検索
↓
4. 収集するURLを大量に集め、urlsに保存
↓
5. hervest.pyを改良して情報を収集
↓
*6. 収集した情報を確認
↓
6. anlys.mdに従いdatabaseを生成
↓
*8. Cheks.mdに従い収集した情報と生成したdatabaseを監査
↓
#9. 監査の内容・スクリプトを確認
↓
7. Git状態を確認してpush
↓
8. Akari-devのワークフローへ戻り作業継続
```

---

# 5. Collection Principles

資料収集では、以下を基本とします。

- 既存の収集済み資料を確認してから新しい資料を収集する。
    
- 既存のURLを確認してからURLを追加する。
    
- 既存のtoolsを確認してから新しいスクリプトを作成する。
    
- 同一または重複する資料を無意味に増やさない。
    
- 収集した情報と、その情報についての分析・解釈を区別する。
    
- 出典となるURLおよび資料との対応関係を維持する。
    
- 収集した資料を変更・加工する場合、その処理内容を確認できるようにする。
    

---

# 6. Search

Web検索および資料収集は `Search.md` に従って実行してください。

検索方法、対象、情報源の扱い等について `Search.md` に規定がある場合は、それを優先してください。

---

# 7. Data Collection

情報収集には既存の `hervest.py` 等のtoolsを使用します。

既存スクリプトを変更する場合は、変更前の動作と変更目的を確認してください。

スクリプトを変更した場合は、収集結果への影響を確認してください。

---

# 8. Verification of Collected Information

`*` のステップでは、収集した情報そのものを確認してください。

以下を確認してください。

- 正しい資料を収集しているか。
    
- 収集対象と内容が一致しているか。
    
- URLと資料の対応が正しいか。
    
- 収集処理によって情報が欠落していないか。
    
- 文字化けや破損がないか。
    
- 重複や不要なデータがないか。
    
- 収集した資料と生成されたdatabaseの対応が維持されているか。
    

---

# 9. Database Generation

databaseの生成は `anlys.md` に従ってください。

databaseを生成する前に、入力となる資料が正しく収集されていることを確認してください。

生成されたdatabaseについても、元資料との対応関係を確認してください。

---

# 10. Audit

`Cheks.md` に従って、収集した情報および生成したdatabaseを監査してください。

監査では、単にdatabaseが生成できたことだけを確認するのではなく、元となる資料との整合性を確認してください。

---

# 11. Problem Workflow for `*` Steps

`*` のステップで問題が発生した場合は、以下のワークフローを実行してください。

```text
1. 問題箇所と原因を確認
↓
2. 因果関係を確認
↓
3. CHECK.md / CLEANROOM.md等に従い修正
↓
4. 修正内容を確認
↓
5. 問題があれば1へ戻る
↓
6. 問題がなければ基本ワークフローへ戻る
```

問題が解決していない場合は、次の工程へ進まないでください。

---

# 12. Audit Problem Workflow

監査の内容、方法、使用したスクリプト等に問題が発生した場合は、以下を確認してください。

```text
1. 監査の内容・方法・スクリプトを確認
↓
2. CHECK.md / CLEANROOM.md等との整合性を確認
↓
3. 問題箇所と原因を特定
↓
4. 修正
↓
5. 修正内容を再確認
↓
6. 必要な監査を再実行
```

監査方法自体に問題がある場合は、監査結果だけを修正して完了扱いにしないでください。

---

# 13. Clean-room Requirements

資料収集、加工、解析、database生成等では、repositoryに定義されたClean-room要件に従ってください。

詳細な要件は `CLEANROOM.md` および関連文書を参照してください。

---

# 14. Git

push前にGit状態を確認してください。

特に以下を確認してください。

- 意図しないファイル変更がない。
    
- 収集対象ではないファイルが変更されていない。
    
- 生成物の変更が意図したものである。
    
- 必要な資料・database・スクリプト変更が含まれている。
    
- commit対象が意図した内容である。
    

push後は、意図したcommitがrepositoryへ反映されていることを確認してください。

---

# 15. Completion

収集・解析・監査が完了したら、`Akari-dev` のワークフローへ戻り、次の作業を継続してください。

このワークフローを必要な作業が完了するまで繰り返します。