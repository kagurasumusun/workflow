# CHECK.md

## 1. Verification Scope

以下を検証します。

### Corpus

- 第三者コードの混入
- 情報の欠落
- 情報の不足
- source provenance
- 入手経路
- 資料の破損
- URL / document mismatch
- CE 世代区分

### Database

- API の欠落
- DLL / export / API の不整合
- header 情報の欠落
- ABI 情報の欠落
- availability matrix の不整合
- source/evidence の欠落
- 世代差分の消失

### Tools

- script bug
- parsing failure
- encoding issue
- duplicate generation
- metadata loss
- incomplete harvesting
- database generation error

### Akari-dev handoff

- database が Akari-dev の必要情報を提供できるか
- API / type / constant / prototype を追跡できるか
- DLL / export / import library を追跡できるか
- CE generation を区別できるか

## 2. Verification Procedure

```text
1. source を確認
↓
2. generated data を確認
↓
3. source ↔ data の対応を確認
↓
4. CE generation を確認
↓
5. cross-reference を確認
↓
6. scripts の処理結果を確認
↓
7. clean-room / provenance を確認
```

## 3. Problem Workflow

問題があれば、

```text
問題箇所
↓
原因
↓
因果関係
↓
根本原因
↓
修正
↓
再検証
```

と進めます。

問題が残ったまま次工程へ進みません。

## 4. Audit the Audit

検証完了時には、検証そのものも確認します。

- 対象範囲が適切か
- 検査条件に漏れがないか
- source が適切か
- script が正しく動作しているか
- 誤った前提を置いていないか
- CHECK.md / CLEANROOM.md から逸脱していないか

一度検証しただけで終了せず、検証条件そのものを見直した上で再検証します。
