# CLEANROOM.md

## 1. Purpose

この repository では、Windows CE の公開仕様・事実を調査することと、
第三者の実装・source text をコピーすることを明確に分離します。

## 2. Prohibited Conduct

以下を行わない。

- Microsoft header source text のコピー
- 非公開 Microsoft source code の取得・利用
- ライセンス上許されない source text の取り込み
- third-party implementation のコピー
- third-party code の Akari-dev への取り込み
- source code を変形して自前実装として扱うこと
- SDK/BSP/OAK/OS の再実装を目的とすること

## 3. Allowed Information

公開仕様から確認できる個々の事実は、必要な provenance を伴って database に
整理できます。

例：

- API name
- type
- constant
- function prototype
- header name
- DLL
- export
- import library
- CE version
- availability
- ABI facts

これらを独自に記述することと、Microsoft header/source text をコピーすることは別です。

## 4. Microsoft Restricted Areas

Shared Source、Visual Studio、Platform Builder 等については、
Microsoft 内部実装をコピーする目的で調査しません。

公開された付属開発資料から仕様や API surface を確認することは、
その資料の利用条件を確認した上で行います。

## 5. Third-party Materials

third-party material は、少なくとも以下を確認します。

- 正当な入手経路である
- 非公開・機密情報ではない
- 不正取得物ではない
- 利用条件に問題がない
- source code のコピーを目的としていない

reverse-engineering reports や個人ブログも、公開性・入手経路・利用条件が
適切であれば資料として利用できます。

## 6. Provenance Audit

資料を利用する前に、可能な範囲で以下を監査します。

- source
- access route
- license / terms
- copyright / trademark notices
- API表現と source text の区別
- redistribution conditions
- source code の混入有無

疑義が解消できない資料は、確定的な根拠として扱いません。
