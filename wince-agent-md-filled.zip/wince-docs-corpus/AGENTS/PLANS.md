# PLANS.md

## 1. Purpose

Windows CE の公開資料・情報を収集、整理、解析し、Akari-dev の構築に必要な
API / ABI / version / DLL / export 等を参照可能な corpus database として完成させる。

## 2. Overall Roadmap

### Phase 0 — Repository foundation
- 既存構造を確認
- 既存 scripts / data / docs を把握
- provenance の扱いを確立

### Phase 1 — Collection infrastructure
- URL collection
- harvesting
- archive / document handling
- metadata handling

### Phase 2 — Corpus collection
- Microsoft official/public materials
- public technical books/manuals
- OEM/vendor documentation
- third-party technical materials
- open-source/reference projects
- reverse-engineering reports

### Phase 3 — API / ABI database
- API
- types
- constants
- prototypes
- headers
- DLLs
- exports
- import libraries
- CE generations
- availability
- ABI information

### Phase 4 — Availability matrix
API ごとの CE generation / version availability を整理する。

### Phase 5 — Verification
- source provenance
- completeness
- generation classification
- consistency
- database ↔ source correspondence
- script correctness

## 3. Dependency / Ordering

```text
wince-docs-corpus
        ↓
API / ABI / version database
        ↓
Akari-dev
        ↓
Development API Surface
```

Akari-dev の実装に必要な事実が corpus に存在しない場合、先に corpus を補完する。

## 4. Information Model

database は少なくとも以下の関係を表現できることを目標とする。

```text
CE generation/version
        ↓
header
        ↓
API/type/constant
        ↓
DLL
        ↓
export
        ↓
import library
```

API availability は API 単位だけでなく CE 世代差を保持する。

Microsoft API reference に OS Versions 等の情報がある場合、それを availability
matrix の第一根拠として扱い、必要に応じて他資料と照合する。

## 5. Non-goals

- Windows CE OS の再実装
- SDK / BSP / OAK の再構築
- Microsoft source code の複製
- third-party source code の取り込み
- corpus 自体を実装コード repository にすること

## 6. Acceptance Criteria

- Akari-dev の構築に必要な情報を検索可能である。
- CE 世代差を失っていない。
- API と DLL / export の対応を追跡できる。
- source / evidence を追跡できる。
- 欠落や不一致を検証できる。
- database の生成過程を再現・監査できる。
