# ANALYSIS.md

## 1. Purpose

収集した資料から、Akari-dev の構築に必要な Windows CE API / ABI database を
生成・更新する。

## 2. Source-to-Fact Separation

解析結果には、可能な限り source/evidence との対応を持たせます。

```text
source document
    ↓
observed fact
    ↓
normalized record
    ↓
cross-reference
    ↓
database
```

推測や解釈を、資料に直接記載された事実として保存しない。

## 3. Database Entities

最低限、以下を表現できる構造を目標とします。

- API
- function
- prototype
- type
- structure
- constant
- header
- DLL
- export
- import library
- ABI
- calling convention
- CE generation
- OS version
- availability
- kernel/user-mode placement
- evidence/source

## 4. DLL / Export Model

API を関数一覧だけで管理せず、

```text
DLL → export → API
```

を第一級の関係として扱います。

世代による DLL / export / API の変化を保持します。

## 5. Normalization

同じ API が複数資料に現れる場合は、単純に重複レコードを作るのではなく、

- 同一性
- version
- source
- 表記差
- prototype 差
- availability 差

を比較します。

不一致を勝手に統合せず、根拠を残します。

## 6. Availability Matrix

API ごとに CE generation / OS version の availability を整理します。

availability の根拠が複数ある場合は、source を保持して比較可能にします。

## 7. Comparative Sources

CeGCC、w32api、ReactOS、Wine、mingw 系等の情報は、
仕様の直接根拠ではなく比較・漏れ検査・調査補助として扱います。

比較資料と official evidence が矛盾する場合、矛盾を隠さず記録し、
primary evidence を優先して再調査します。

## 8. Database Acceptance

database は以下を満たすことを目標とします。

- source を追跡できる
- CE 世代を追跡できる
- DLL / export / API を相互に追跡できる
- availability を追跡できる
- prototype / type / constant を検索できる
- 欠落・不一致を検出できる
- generation differences を失わない
