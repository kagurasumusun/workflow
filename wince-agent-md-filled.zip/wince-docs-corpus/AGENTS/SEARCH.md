# SEARCH.md

## 1. Search Priority

調査では、原則として以下の順で情報を探します。

### Layer 1 — Primary / official-public evidence

- Microsoft Learn
- Microsoft MSDN archive
- Microsoft technical articles
- Microsoft Windows CE documentation
- Microsoft public documentation archives
- Wayback Machine / public archives
- 公開された CE 技術書・manual
- 公開された MCTS 等の技術資料

### Layer 2 — Trusted technical documentation

- OEM vendor documentation
- Toradex 等の大手 vendor documentation
- public manuals
- public CE development examples
- trusted technical references

### Layer 3 — Comparative / supplementary evidence

- CeGCC / mingw32ce
- w32api
- open-source projects
- GitHub
- mailing-list archives
- Stack Overflow
- reverse-engineering reports
- 個人技術資料

Layer 3 は Windows CE の仕様そのものとみなさず、Layer 1 / 2 の不足確認、
比較、追加調査の手掛かりとして使用します。

## 2. Search Objectives

単純に API 名を検索するだけではなく、以下を調べます。

- API
- type
- constant
- prototype
- header
- DLL
- export
- import library
- calling convention
- ABI
- CE generation
- OS version
- availability
- kernel / user mode
- API の配置
- 前世代からの変更

## 3. DLL-first Research

API reference を関数単位だけで収集せず、

```text
CE generation
    ↓
DLL
    ↓
export
    ↓
API
```

の逆方向からも調査します。

Windows CE では世代によって API の配置や構成が変化する可能性があるため、
DLL / export / API の対応を世代情報と一緒に保持します。

## 4. Availability Matrix

Microsoft API reference が OS Versions / availability を示している場合、
availability matrix の第一根拠として利用します。

ただし、単一資料だけで世代差を確定せず、重要な差異は複数資料と照合します。

## 5. Microsoft Restricted Source Areas

Shared Source、Visual Studio、Platform Builder 等については、
Microsoft の内部実装をコピーする目的で source code を収集・利用しません。

許可される範囲では、付属する公開開発資料から、

- API
- header name
- DLL
- version
- ABI
- development requirements

等を確認します。

## 6. URL Collection

検索結果を採用する際は、

- URL
- title
- source/site
- document type
- version / CE generation
- relevance
- provenance
- access status

等を可能な範囲で記録します。

既存 URL を確認してから追加し、重複を避けます。
