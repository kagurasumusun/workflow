# RULE.md

## 1. Core Rule

この repository の目的は「Windows CE の事実を収集・整理すること」であり、
第三者の実装を取り込むことではありません。

## 2. Facts vs Source Text

以下は別の問題として扱います。

- API 名
- 型名
- 定数
- 関数 prototype
- header 名
- DLL 名
- export
- import library
- version / availability
- ABI に関する事実

と、

- Microsoft header の source text
- ライセンスで保護された source text
- 非公開 source code
- third-party source code

は同一視しません。

公開仕様から確認できる個々の事実を database に整理することと、
source text をコピーすることは別です。

## 3. Clean-room Implementation Boundary

Akari-dev へ渡す情報は仕様・事実・根拠として整理します。

第三者コードをコピー、取り込み、変形して実装することを避け、
Akari-dev では独自に記述します。

## 4. Source Classification

情報源には役割を持たせます。

### First layer

- Microsoft Learn
- Microsoft MSDN archive
- Microsoft technical articles
- Microsoft CE documentation
- Wayback / public archives
- 古い CE 技術書
- MCTS 等の公開資料

これらから、仕様、API、DLL、version、availability、ABI 等を確認します。

### Supplementary / near-first layer

- OEM vendor documentation
- Toradex 等の大手 vendor documentation
- public manuals
- public CE development examples

### Comparative layer

- CeGCC / mingw32ce
- w32api
- open-source projects
- GitHub source
- mailing-list archives
- Stack Overflow
- reverse-engineering reports

比較層は仕様そのものとして扱わず、欠落確認、構造比較、追加調査の手掛かりとして使用します。

## 5. ReactOS / Wine / MinGW Family

ReactOS、Wine、mingw-w64、mingw-w32、w32api、w64api 等は Windows CE
そのものの資料として直接使用しません。

これらは clean-room compatibility project の構造、API surface の整理方法、
tooling 等を考える際の補助資料として扱います。

## 6. CeGCC / mingw32ce

CeGCC / mingw32ce は仕様ではありません。

w32api をコピーする元として扱わず、Akari-dev の API database に漏れがないか、
API surface や DLL / export の比較対象として利用します。

## 7. Scope

第三者資料は、合法かつ正当な入手経路で、非公開・機密情報ではないことを
確認できる範囲を対象とします。

個人ブログ、reverse-engineering report 等も、入手経路・公開性・利用条件が
適切であれば資料候補になり得ます。

ただし、source code の取り込みや再配布を目的に使用しません。
