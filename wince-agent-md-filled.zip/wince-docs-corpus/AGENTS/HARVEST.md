# HARVEST.md

## 1. Purpose

`urls/` に整理した資料候補を、再利用可能な corpus として `docs/` 等へ収集する。

## 2. Before Harvest

- 既存 URL を確認する。
- 既存資料を確認する。
- 同一資料の重複取得を避ける。
- source / provenance を確認する。
- 利用条件や公開性に問題がないか確認する。

## 3. Harvest Requirements

収集時には可能な限り以下を保持する。

- original URL
- archive URL がある場合はその対応
- title
- source/site
- publication/update information
- document type
- CE version / generation
- retrieval information
- relevant metadata

取得した内容を加工する場合は、原資料との対応を失わないようにする。

## 4. Scripts

既存の harvesting script を先に確認する。

script を変更する場合は、

1. 変更前の動作を確認
2. 変更目的を明確化
3. 変更
4. 小規模な入力で検証
5. 収集結果への影響を確認
6. 必要な全体処理を再実行

とする。

## 5. Data Integrity

以下を検査する。

- 欠落
- 文字化け
- HTML/PDF 等の破損
- URL mismatch
- duplicate
- 不完全取得
- metadata loss
- archive source の取り違え

取得できなかった資料を取得済みとして扱わない。
