# AGENTS.md

## 1. Repository Role

このリポジトリはWindows CEのDevelopment API Surface Kitを構築するリポジトリです。

このリポジトリは以下を目的とするものではありません。

- SDKの再構築
    
- BSPの構築
    
- OAKの構築
    
- Windows CE OSの再実装
    

---

## 2. Repository Structure

リポジトリrootは以下の構造を基本とします。

```text
Akari-dev/
├── include/
├── AGENTS/
├── def/
├── lib/
└── tools/
```

### `include/`

Declarationsを配置します。

### `def/`

ABI / export contractを配置します。

### `lib/`

Linker interfaceを配置します。

### `tools/`

Generators / toolsを配置します。

既存のrepository構造を変更する場合は、変更前に既存設計と目的を確認してください。

---

# 3. Basic Workflow

このrepositoryでは、原則として以下のワークフローを繰り返します。

```text
1. 既存Akari-dev確認
↓
2. wince-docs-corpus確認
↓
3. Windows CE公開情報を調査
↓
4. Windows CE仕様を確認
↓
5. 既存実装をコードレベルで調査
↓
6. 独自実装・修正
↓
7. ビルド・コード検証
↓
*8. 資料との照合
↓
8. git diff確認
↓
*10. 検証
↓
*11. Clean-room確認
↓
*12. 目的逸脱確認
↓
#13. 監査自体の内容・方法を確認
↓
9. commit / push
↓
次の作業へ
```

---

## 4. Workflow Principles

### 4.1 Existing Work First

作業を開始する前に、対象となる既存コード、既存資料、既存スクリプト、既存テストを確認してください。

既存実装を確認せずに同等の機能を新規実装しないでください。

### 4.2 Documentation Before Implementation

実装前に、利用可能なWindows CE公開情報および `wince-docs-corpus` の資料を確認してください。

資料によって確認できる事実と、資料から推測した内容を区別してください。

### 4.3 Specification and Implementation

Windows CEの仕様上必要な内容と、現在のAkari-devの実装内容を分けて確認してください。

既存実装が仕様と一致しているとは限りません。

既存実装が仕様と異なる場合は、その差異を確認した上で修正してください。

### 4.4 Minimal Changes

目的を達成するために必要な範囲を超えてコードや構造を変更しないでください。

無関係なリファクタリング、ファイル移動、命名変更等を同時に行わないでください。

---

# 5. Build and Verification

実装・修正後は、対象に応じたビルドおよびコード検証を行ってください。

検証では以下を区別してください。

- 実際に実行した検証
    
- 実行できなかった検証
    
- 資料による確認
    
- コードによる確認
    
- 推測による判断
    

実行していないテストや検証を成功したものとして扱わないでください。

---

# 6. Problem Workflow for `*` Steps

基本ワークフローで `*` が付いているステップに問題が発生した場合は、以下のワークフローを実行してください。

```text
1. 問題場所を確認
↓
2. 原因と関連情報を確認
↓
3. 問題箇所と原因の因果関係を調査
↓
4. 根本原因と問題箇所を修正
↓
5. 問題が発生した `*` の検査を再実行
↓
6. 問題があれば1へ戻る
↓
7. 問題がなければ、再度 `*` の調査条件を見直す
↓
8. 問題がなければ基本ワークフローの次へ進む
```

問題が解決していない場合は、問題を無視して基本ワークフローの次の工程へ進まないでください。

---

# 7. Audit Workflow for `#` Steps

`#` が付いているステップは監査ステップです。

監査で問題が発生した場合は、以下のワークフローを実行してください。

```text
1. 監査の内容・方法・使用したスクリプト等が
   CLEANROOM.md / CHECK.mdの内容に沿っているか確認
↓
2. 問題箇所と原因を特定
↓
3. 問題箇所をCLEANROOM.md / CHECK.mdの内容に合わせて修正
↓
4. 妥当性と逸脱の有無を確認
↓
5. 問題があれば1へ戻る
↓
6. 問題がなければ基本ワークフローへ戻る
```

監査そのものにも問題がある可能性を考慮してください。

---

# 8. Audit the Audit

監査では、対象だけでなく監査自体についても確認します。

以下を確認してください。

- 監査対象が適切か。
    
- 監査方法が適切か。
    
- 使用した資料が適切か。
    
- 使用したスクリプトが適切か。
    
- 検査条件に不足がないか。
    
- 誤った前提に基づいて監査していないか。
    
- `CLEANROOM.md` / `CHECK.md` 等から逸脱していないか。
    

監査方法自体に問題がある場合は、その問題を修正してから監査を再実行してください。

---

# 9. wince-docs-corpus Dependency

問題の原因または問題を判断するために必要な情報が `wince-docs-corpus` の資料に存在する場合は、`wince-docs-corpus` の問題発生時手順に従ってください。

資料が不足している場合は、推測だけで結論を確定しないでください。

---

# 10. Clean-room Requirements

Windows CEのAPI、ABI、仕様、実装等を扱う場合は、repositoryに定義されたClean-room要件に従ってください。

詳細な要件は `CLEANROOM.md` および関連文書を参照してください。

Clean-room要件に問題がある場合は、その問題を解決してから作業を継続してください。

---

# 11. Completion Requirements

作業を完了として扱う前に、少なくとも以下を確認してください。

- 目的を達成している。
    
- 意図しないファイル変更がない。
    
- `git diff` を確認している。
    
- 必要なビルド・検証を実行している。
    
- 検証結果を確認している。
    
- 資料との照合が必要な場合は照合している。
    
- Clean-room要件を満たしている。
    
- 目的から逸脱していない。
    
- commit対象が意図した変更だけである。
    

---

# 12. Commit / Push

検証および監査が完了してからcommit / pushしてください。

commit / push前にGit状態を確認し、意図しない変更を含めないでください。

push後は、実際に意図したcommitがrepositoryへ反映されていることを確認してください。

---

# 13. Continuous Workflow

作業完了後は、workspaceの次の作業へ継続します。

このワークフローは、対象となる作業が完了するまで繰り返します。


## Detailed Documents

- `AGENTS/PLANS.md` — implementation plans
- `AGENTS/RULE.md` — implementation rules
- `AGENTS/ARCHITECTURE.md` — architecture and component boundaries
- `AGENTS/CORRECTR.md` — correctness and specification verification
- `AGENTS/CLEANROOM.md` — clean-room requirements
- `AGENTS/CHECK.md` — verification procedures
- `AGENTS/CODE_REVIEW.md` — code review requirements