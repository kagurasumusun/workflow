# CLEANROOM.md

## 1. Purpose

Akari-dev は clean-room で Windows CE Development API Surface を独自実装します。

## 2. Prohibited

- Microsoft header source text のコピー
- 非公開 source code の利用
- third-party implementation のコピー
- third-party code の取り込み
- source text を変形して自前実装として扱うこと
- SDK/BSP/OAK/OS の再実装

## 3. Allowed Basis

公開仕様から得られた、

- API
- type
- constant
- prototype
- header name
- DLL
- export
- import library
- ABI facts
- version / availability

等を根拠として、独自に declarations / definitions / generators を記述します。

## 4. Provenance

実装に使用した重要な仕様判断について、必要に応じて corpus の evidence に
戻れるようにします。

source text のコピーではなく、仕様上の事実を独自表現で実装します。
