# CHECK.md

## 1. Verification Scope

- source / specification
- API completeness
- ABI
- header declarations
- DLL / export
- import library
- CE generation / version
- kernel/user mode placement
- build
- binary / generated output
- regression
- clean-room provenance
- repository scope

## 2. Procedure

```text
implementation
↓
build / code verification
↓
corpus database comparison
↓
ABI / API / export checks
↓
generated artifact inspection
↓
clean-room check
↓
scope check
↓
git diff
```

実行した検証、実行できなかった検証、資料による確認、コードによる確認、
推測による判断を区別します。

## 3. Problem Workflow

問題があれば原因・因果関係・根本原因を確認し、修正後に同じ検査を再実行します。

## 4. Audit the Audit

監査対象だけでなく、

- 検査条件
- scripts
- 使用資料
- 前提
- 検査範囲

自体を確認します。
