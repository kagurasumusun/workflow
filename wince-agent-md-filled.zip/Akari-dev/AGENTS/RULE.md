# RULE.md

## 1. Core Rules

- 既存実装を確認してから実装する。
- `wince-docs-corpus` の evidence を確認してから仕様を確定する。
- 仕様と既存実装を別々に検証する。
- 不明な仕様を推測で確定しない。
- 必要最小限の変更にする。

## 2. Windows CE Boundary

Windows CE は Win32 と同一ではありません。

Win32 の資料や実装を Windows CE API の直接的な根拠として扱わないでください。
Win32 系資料は、必要な場合に系譜や設計背景を理解する補助資料として扱います。

## 3. API / ABI

API 名、型、prototype、constant、header name と、
ABI / export / import library は別々に検証します。

API が存在することだけを確認して、DLL、export、calling convention、
version、availability を推測しないでください。

## 4. Clean-room

第三者コードをコピー、取り込み、変形して実装しません。

公開仕様・事実を根拠として、独自に記述します。

詳細は `CLEANROOM.md` を参照してください。
