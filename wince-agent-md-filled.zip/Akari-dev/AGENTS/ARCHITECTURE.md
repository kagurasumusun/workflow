# ARCHITECTURE.md

## 1. Purpose

Akari-dev は Windows CE Development API Surface Kit を構築する repository です。

SDK、BSP、OAK、Windows CE OS の再実装ではありません。

## 2. Root Structure

```text
Akari-dev/
├── include/
├── AGENTS/
├── def/
├── lib/
└── tools/
```

### include/

API declarations、types、constants 等の公開 interface を配置します。

### def/

ABI / export contract を表現します。

### lib/

linker interface / import library 関連を配置します。

### tools/

generator、validation、conversion 等の tools を配置します。

## 3. Boundary

```text
wince-docs-corpus
        ↓
documented facts / evidence
        ↓
Akari-dev
├── declarations
├── ABI/export contracts
├── linker interfaces
└── generators
```

corpus は情報源、Akari-dev はその情報から独自に構築する Development API Surface です。

## 4. Design Principles

- API surface と implementation を分離する。
- declaration と ABI/export contract を分離する。
- linker interface を declaration から独立して検証可能にする。
- generated files と hand-written files を区別する。
- CE generation / version 差を消さない。
- Win32 と Windows CE を同一視しない。
