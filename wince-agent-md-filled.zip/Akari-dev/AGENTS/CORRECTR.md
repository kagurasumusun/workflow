# CORRECTR.md

## 1. Purpose

Akari-dev の実装が Windows CE の documented API / ABI / version information と
整合しているかを判断するための規則です。

## 2. Evidence Order

原則として、

1. wince-docs-corpus の primary evidence
2. 複数の信頼できる公開資料の突き合わせ
3. trusted third-party documentation
4. comparative implementation

の順で根拠を評価します。

comparative implementation は仕様そのものではありません。

## 3. Verification Items

対象に応じて以下を確認します。

- API name
- prototype
- type
- constant
- header
- DLL
- export
- import library
- calling convention
- ABI
- structure layout
- CE generation
- OS version
- availability
- kernel/user mode
- linker behavior

## 4. Conflict Handling

資料が一致しない場合は、矛盾を隠さず記録します。

特に CE generation / version 差を一つの universal definition に統合しないでください。

不明な事項は「未確認」として扱い、推測を verified fact に昇格させません。
