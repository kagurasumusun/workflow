# PLANS.md

## 1. Purpose

Windows CE の Development API Surface Kit を構築する。

これは SDK、BSP、OAK、Windows CE OS の再実装ではない。

## 2. Overall Roadmap

```text
Phase 0  Repository foundation
Phase 1  wince-docs-corpus
Phase 2  API Surface directories
Phase 3  generators / scripts
Phase 4  Windows CE API surface
Phase 5  program startup code
Phase 6  verification
```

## 3. Dependency / Ordering

```text
wince-docs-corpus
        ↓
Windows CE API / ABI information
        ↓
wince Development API Surface
        ↓
program development
```

startup code は API surface と並行して、必要な ABI / runtime requirements を
資料と照合しながら構築する。

## 4. Research Requirements

`wince-docs-corpus` database を使用して少なくとも以下を突き合わせる。

- ABI
- API
- header name
- type
- constant
- prototype
- DLL
- export
- import library
- CE generation
- OS version
- availability
- kernel/user mode 等

## 5. Implementation Strategy

公開仕様から独自に API Surface を構築する。

第三者コードをコピーせず、source text を変形利用しない。

## 6. Verification Strategy

完成を、単に build が通ることだけで判断しない。

少なくとも、

- corpus database との照合
- API / ABI completeness
- DLL / export / linker interface
- CE generation
- build
- generated output
- clean-room
- repository scope

を確認する。

## 7. Non-goals

- Windows CE OS implementation
- SDK reconstruction
- BSP reconstruction
- OAK reconstruction
- third-party implementation import

## 8. Acceptance Criteria

必要な Development API Surface が corpus の evidence と照合可能であり、
不足や不一致が確認・修正できる状態を完成条件とする。

## 9. Current Progress

現在の進捗をここに記録する。

## 10. Surprises & Discoveries

- Windows CE は Win32 と同一ではない。
- WinCE API には Win32 系譜を持つものがある。
- CE generation により API の配置・availability が変化する。
- Windows CE は Windows NT ではない。

## 11. Outcomes & Retrospective

完了時に結果、残課題、発見事項、検証結果を記録する。
