# CODE_REVIEW.md

## Review Checklist

### Scope
- Development API Surface の範囲内か
- SDK/BSP/OAK/OS 再実装になっていないか
- 不要な変更を含まないか

### API
- API / type / constant / prototype が根拠と一致するか
- header placement が適切か
- CE generation 差を保持しているか

### ABI
- calling convention
- type layout
- export name
- DLL
- import library
- version
- architecture-specific behavior

を必要に応じて確認する。

### Clean-room
- third-party code が混入していないか
- source text を変形利用していないか
- provenance が説明可能か

### Generated files
- generator の入力・出力が妥当か
- 手動変更と generated content の境界が明確か

### Verification
- build/test が実行されているか
- 未実行の検証を成功扱いしていないか
- corpus database と照合しているか
