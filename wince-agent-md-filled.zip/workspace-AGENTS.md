# AGENTS.md

## 1. Repository Role

このリポジトリは、Windows CE に関する資料・情報を収集し、その情報をもとに
Windows CE Development API Surface Kit を構築するための workspace です。

```text
repository/
├── Akari-dev/
└── wince-docs-corpus/
```

`Akari-dev` と `wince-docs-corpus` は Git submodule です。

## 2. Repository Responsibilities

```text
wince-docs-corpus
        │
        │ 資料・仕様・API/ABI情報
        ▼
Akari-dev
        │
        │ Development API Surface
        ▼
Windows CE application development
```

`wince-docs-corpus` は `Akari-dev` の前提資料です。
`Akari-dev` で必要な情報が不足している場合、推測だけで実装を確定せず、
まず `wince-docs-corpus` 側で不足情報を調査します。

逆に、資料だけでは判断できない事項については `Akari-dev` 側の実装・ABI・
ビルド結果と照合します。

## 3. General Rules

- 作業開始時に対象 repository の `AGENTS.md` を確認する。
- 既存の資料、実装、scripts、tests、生成物を確認してから変更する。
- 資料上の事実、推測、実装上の判断を混同しない。
- 検証していない内容を検証済みとして扱わない。
- 問題が解決していない状態で次の工程へ進まない。
- 不要なリファクタリングや構造変更を行わない。
- `wince-docs-corpus` の既存ディレクトリ構造を workspace 側から変更しない。

## 4. Submodule Push

submodule の push には `GITHUB_PAT` を使用し、`kagurasumusun` として push します。

push 後は workspace 側で以下を確認します。

1. submodule が意図した commit を指している。
2. workspace の submodule pointer がその commit を指している。
3. `git status` / `git diff` に意図しない変更がない。
4. workspace 側の pointer 更新を commit する。

## 5. Detailed Instructions

各 repository の詳細は、それぞれの `AGENTS.md` と `AGENTS/` 以下の文書に従います。

workspace の AGENTS.md に submodule 固有の詳細な規則を重複して記載しません。
